1) use Mondra.SustainabilityCalculator.exe to launch the calc
2) use /schema/farmed-crop-schema.json to compose an observations file
3) create the observation file, then provide its location to console prompt
	or use sample/Plenish.json
4)navigate to /results folder for results